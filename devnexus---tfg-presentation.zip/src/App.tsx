/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Cpu, 
  Database, 
  Layout, 
  ShieldCheck, 
  Code2, 
  MessageSquare, 
  Calendar, 
  Terminal,
  Layers,
  BrainCircuit,
  Zap,
  Globe,
  ArrowRight,
  Users
} from 'lucide-react';

// --- Types ---
interface SlideData {
  id: number;
  section: string;
  title: React.ReactNode;
  subtitle: string;
  content: React.ReactNode;
  metrics?: { value: string; label: string }[];
  visual?: React.ReactNode;
}

// --- Components ---

const Tag = ({ children, color }: { children: React.ReactNode; color: string }) => {
  const colors: Record<string, string> = {
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    emerald: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    red: 'bg-red-500/10 text-red-400 border-red-500/20',
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold border uppercase tracking-wider ${colors[color] || colors.blue}`}>
      {children}
    </span>
  );
};

interface SlideProps {
  slide: SlideData;
  direction: number;
  currentSlide: number;
  key?: React.Key;
}

const Slide = ({ slide, direction, currentSlide }: SlideProps) => {
  return (
    <motion.div
      key={slide.id}
      initial={{ x: direction > 0 ? '100%' : '-100%', opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: direction > 0 ? '-100%' : '100%', opacity: 0 }}
      transition={{ type: 'spring', damping: 30, stiffness: 100 }}
      className={`absolute inset-0 flex flex-col justify-center px-12 md:px-24 ${currentSlide === 0 ? 'pt-32 pb-32' : 'pt-12 pb-12'}`}
    >
      <div className="grid grid-cols-12 gap-12 lg:gap-20 w-full max-w-[1500px] mx-auto items-center">
        <div className="col-span-12 lg:col-span-7 flex flex-col justify-center space-y-8">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="space-y-6"
          >
            <div className="flex items-center gap-3">
              <span className="inline-block px-3 py-1 glass rounded-full text-[10px] uppercase tracking-widest text-brand-gold font-bold">
                {slide.section}
              </span>
            </div>
            <h2 className="text-5xl md:text-7xl font-serif leading-tight text-white italic drop-shadow-md">
              {slide.title}
            </h2>
            <p className="text-xl text-slate-400 font-light max-w-xl leading-relaxed">
              {slide.subtitle}
            </p>
          </motion.div>
          
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="w-full"
          >
            {slide.metrics && (
              <div className="flex gap-12 mb-10 overflow-x-auto pb-4 no-scrollbar">
                {slide.metrics.map((m, i) => (
                  <React.Fragment key={i}>
                    <div>
                      <p className="text-3xl font-serif text-white">{m.value}</p>
                      <p className="text-[10px] uppercase tracking-widest text-slate-500 mt-1 whitespace-nowrap">{m.label}</p>
                    </div>
                    {i < slide.metrics.length - 1 && (
                      <div className="w-px h-10 bg-white/10 self-center hidden sm:block"></div>
                    )}
                  </React.Fragment>
                ))}
              </div>
            )}
            <div className="text-slate-300">
              {slide.content}
            </div>
          </motion.div>
        </div>

        <div className="hidden lg:col-span-5 lg:flex flex-col items-center justify-center">
           <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
            className="w-full relative"
           >
             {slide.visual || (
               <div className="aspect-[4/5] glass rounded-3xl flex items-center justify-center relative overflow-hidden border-white/5">
                 <div className="absolute inset-0 bg-brand-gold/5 blur-[80px]" />
                 <Code2 className="w-20 h-20 text-brand-gold/20" />
                 <p className="absolute bottom-10 text-[10px] uppercase tracking-[0.3em] text-slate-600">Representación Visual</p>
               </div>
             )}
           </motion.div>
        </div>
      </div>
    </motion.div>
  );
};

const Metric = ({ icon: Icon, value, label }: any) => (
  <div className="flex items-center gap-4">
    <div className="w-12 h-12 glass rounded-xl flex items-center justify-center border border-brand-gold/20">
      <Icon className="w-6 h-6 text-brand-gold" />
    </div>
    <div>
      <p className="text-xl font-serif text-white">{value}</p>
      <p className="text-[10px] uppercase tracking-widest text-slate-500">{label}</p>
    </div>
  </div>
);

// --- App Main ---

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [direction, setDirection] = useState(0);
  const slides: SlideData[] = [
    {
      id: 0,
      section: "PRESENTACIÓN PROYECTO 2026",
      title: <>Plataforma <br/> <span className="gold-gradient">DevNexus</span></>,
      subtitle: "Unificando la gestión de diarios, incidencias y comunicación para equipos de desarrollo.",
      metrics: [
        { value: "DAM", label: "Ciclo Superior" },
        { value: "SaaS", label: "Arquitectura" },
        { value: "4.5m", label: "Desarrollo" }
      ],
      content: (
        <div className="space-y-4">
          <p className="text-slate-400 font-light leading-relaxed">
            Una solución integral diseñada para eliminar la dispersión de herramientas (Slack, Excel, Jira) centralizando la trazabilidad en un entorno seguro y eficiente.
          </p>
        </div>
      ),
      visual: (
        <div className="relative w-full aspect-square flex items-center justify-center">
          <div className="absolute inset-0 bg-brand-gold/10 blur-[120px] rounded-full animate-pulse" />
          <div className="relative p-12 glass rounded-full border-2 border-brand-gold/20 shadow-[0_0_50px_rgba(197,160,89,0.1)]">
            <Cpu className="w-40 h-40 text-brand-gold" />
          </div>
          <div className="absolute -top-4 -right-4 p-5 glass rounded-2xl animate-float">
             <ShieldCheck className="w-10 h-10 text-emerald-400" />
          </div>
          <div className="absolute -bottom-4 -left-4 p-5 glass rounded-2xl animate-float [animation-delay:2s]">
             <Zap className="w-10 h-10 text-amber-500" />
          </div>
        </div>
      )
    },
    {
      id: 1,
      section: "01. PROBLEMA & SOLUCIÓN",
      title: <>Trazabilidad vs <br/> <span className="gold-gradient">Fragmentación</span></>,
      subtitle: "La dispersión de información es la mayor causa de ineficiencia en el desarrollo moderno.",
      metrics: [
        { value: "30%", label: "Tiempo Perdido" },
        { value: "4+", label: "Apps Dispares" }
      ],
      content: (
        <div className="space-y-6">
          <div className="p-5 glass rounded-2xl border-l-4 border-red-500/40">
            <h4 className="font-bold text-white mb-1 uppercase tracking-widest text-[10px]">El Problema Real</h4>
            <p className="text-sm text-slate-400">Información técnica crítica perdida entre chats, correos y hojas de cálculo, dificultando las auditorías y el aprendizaje.</p>
          </div>
          <div className="p-5 glass-gold rounded-2xl border-l-4 border-brand-gold">
            <h4 className="font-bold text-white mb-1 uppercase tracking-widest text-[10px]">La Solución Unificada</h4>
            <p className="text-sm text-slate-300">DevNexus centraliza diarios de progreso, gestión de tickets y un IDE integrado en una única fuente de verdad técnica.</p>
          </div>
        </div>
      ),
      visual: (
        <div className="grid grid-cols-2 gap-4 w-full">
           {[
             { icon: MessageSquare, label: "Comunicación", color: "blue" },
             { icon: Terminal, label: "Prototipado", color: "purple" },
             { icon: ShieldCheck, label: "Auditoría", color: "green" },
             { icon: Database, label: "Trazabilidad", color: "amber" },
           ].map((item, i) => (
             <div key={i} className="aspect-square glass rounded-3xl flex flex-col items-center justify-center group hover:bg-white/5 transition-all hover:-translate-y-1">
               <item.icon className="w-12 h-12 text-slate-500 group-hover:text-brand-gold transition-colors mb-3" />
               <span className="text-[10px] uppercase tracking-widest text-slate-600 font-bold group-hover:text-slate-300">{item.label}</span>
             </div>
           ))}
        </div>
      )
    },
    {
      id: 2,
      section: "02. FUNCIONALIDAD: DIARIOS",
      title: <>Documentación <br/> <span className="gold-gradient">en Tiempo Real</span></>,
      subtitle: "Bitácora técnica estructurada por proyectos y temas con flujo de mentoría.",
      metrics: [
        { value: "Multivista", label: "Pública / Privada" },
        { value: "Review", label: "Flujo Staff" }
      ],
      content: (
        <div className="space-y-4">
          <p className="text-sm text-slate-400 leading-relaxed">
            Permite el registro detallado de avances técnicos. La clave es el <strong>Control de Visibilidad</strong>: una entrada puede ser privada, pública o estar pendiente de revisión por un tutor (Staff).
          </p>
          <div className="grid grid-cols-2 gap-4 pt-4">
             <div className="p-4 glass rounded-xl">
               <h5 className="text-brand-gold font-bold text-xs mb-1">Feedback Tutor</h5>
               <p className="text-[10px] text-slate-500">Comentarios directos del staff sobre el progreso del alumno.</p>
             </div>
             <div className="p-4 glass rounded-xl">
               <h5 className="text-brand-gold font-bold text-xs mb-1">Markdown Ready</h5>
               <p className="text-[10px] text-slate-500">Exportación optimizada para documentación técnica profesional.</p>
             </div>
          </div>
        </div>
      ),
      visual: (
        <div className="glass rounded-3xl overflow-hidden border-white/5 shadow-2xl">
           <div className="bg-white/5 p-5 border-b border-white/10 flex justify-between items-center">
              <span className="text-xs font-bold text-brand-gold uppercase tracking-widest font-mono">activity_heatmap.component</span>
              <div className="flex gap-2">
                 <div className="w-2 h-2 rounded-full bg-red-400/30" />
                 <div className="w-2 h-2 rounded-full bg-amber-400/30" />
                 <div className="w-2 h-2 rounded-full bg-emerald-400/30" />
              </div>
           </div>
           <div className="p-10 space-y-6">
              <div className="grid grid-cols-12 gap-1.5 h-32">
                 {[...Array(96)].map((_, i) => (
                   <div key={i} className={`aspect-square rounded-[2px] transition-colors ${i % 7 === 0 || i % 11 === 0 ? 'bg-brand-gold/60' : 'bg-white/5'}`} />
                 ))}
              </div>
              <div className="flex justify-between items-center text-[10px] uppercase tracking-widest font-bold">
                 <span className="text-slate-600">Baja Actividad</span>
                 <div className="flex gap-1">
                    <div className="w-3 h-3 bg-white/5 rounded-sm" />
                    <div className="w-3 h-3 bg-brand-gold/20 rounded-sm" />
                    <div className="w-3 h-3 bg-brand-gold/40 rounded-sm" />
                    <div className="w-3 h-3 bg-brand-gold rounded-sm" />
                 </div>
                 <span className="text-brand-gold">Alta Actividad</span>
              </div>
           </div>
        </div>
      )
    },
    {
      id: 3,
      section: "03. FUNCIONALIDAD: IDE INTEGRADO",
      title: <>Entorno de <br/> <span className="gold-gradient">Edición Propio</span></>,
      subtitle: "Acortando la distancia entre la ejecución y la documentación técnica.",
      metrics: [
        { value: "Monaco", label: "Editor Engine" },
        { value: "PgSQL", label: "Persistencia" }
      ],
      content: (
        <div className="space-y-6">
          <p className="text-sm text-slate-400 leading-relaxed">
            Hemos integrado un IDE completo para que el desarrollador pueda portar snipets de código o proyectos enteros directamente a su diario sin salir de la plataforma.
          </p>
          <ul className="space-y-3">
             {[
               { t: "Árbol de Archivos", d: "Estructura de carpetas anidadas persistidas en DB." },
               { t: "Sandbox Live", d: "Previsualización inmediata de cambios en proyectos web." },
               { t: "Sintaxis Pro", d: "Resaltado avanzado de múltiples lenguajes (Monaco)." },
             ].map((f, i) => (
               <li key={i} className="flex gap-4">
                  <div className="w-5 h-5 bg-brand-gold/10 rounded flex items-center justify-center shrink-0">
                    <ChevronRight className="w-3 h-3 text-brand-gold" />
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-white">{f.t}</h5>
                    <p className="text-[10px] text-slate-500">{f.d}</p>
                  </div>
               </li>
             ))}
          </ul>
        </div>
      ),
      visual: (
        <div className="glass rounded-2xl overflow-hidden border-white/10 shadow-2xl bg-[#1e1e1e] flex flex-col">
           <div className="h-40 flex border-b border-white/5">
              <div className="w-32 border-r border-white/5 p-3 space-y-1.5 overflow-hidden">
                 <div className="text-[8px] text-slate-500 uppercase tracking-widest mb-2 font-bold">Filesystem</div>
                 <div className="flex items-center gap-2 text-[9px] text-slate-300 font-mono"><Layers className="w-3 h-3" /> src/</div>
                 <div className="flex items-center gap-2 text-[9px] text-brand-gold pl-3 font-mono border-l border-brand-gold/30"><Code2 className="w-3 h-3" /> main.ts</div>
                 <div className="flex items-center gap-2 text-[9px] text-slate-500 pl-3 font-mono opacity-50"><Database className="w-3 h-3" /> config.sql</div>
              </div>
              <div className="flex-1 p-4 font-mono text-[9px] space-y-1 overflow-hidden opacity-80">
                 <p className="text-blue-400">@Component<span className="text-white">({'{'}</span></p>
                 <p className="pl-4">selector: <span className="text-emerald-300">'app-root'</span>,</p>
                 <p className="pl-4">template: <span className="text-emerald-300">`&lt;view&gt;...&lt;/view&gt;`</span></p>
                 <p className="text-white">{'}'})</p>
                 <p className="text-purple-400 mt-2">export class <span className="text-blue-300">App</span> {'{'}</p>
                 <p className="pl-4">init() {'{'} <span className="text-slate-500">/* lógica */</span> {'}'}</p>
              </div>
           </div>
           <div className="h-24 bg-white/5 p-4 flex items-center justify-center">
              <div className="flex items-center gap-4 animate-pulse">
                 <Zap className="w-6 h-6 text-brand-gold" />
                 <span className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em]">Live Sandbox Ready</span>
              </div>
           </div>
        </div>
      )
    },
    {
      id: 4,
      section: "04. INTELIGENCIA ARTIFICIAL",
      title: <>Automatización <br/> <span className="gold-gradient">del Esfuerzo</span></>,
      subtitle: "Integración de LLMs (Groq Llama 3.3) para potenciar la productividad y auditoría.",
      metrics: [
        { value: "Llama 3.3", label: "Model Engine" },
        { value: "Groq", label: "Inference Tech" }
      ],
      content: (
        <div className="grid grid-cols-2 gap-4 pt-4">
           {[
             { title: "Scan IA (Vision)", desc: "Captura fotos de pizarras o código y las transcribe al diario con precisión OCR.", icon: BrainCircuit },
             { title: "Code Auditor", desc: "Revisión automática de lógica y sugerencias de mejora técnica instantáneas.", icon: ShieldCheck },
             { title: "Smart Tags", desc: "Categorización automática de entradas de diario basada en el contexto técnico.", icon: Layers },
             { title: "Dashboard Gen", desc: "Generación de resúmenes ejecutivos automáticos para el Staff docente.", icon: Layout },
           ].map((item, i) => (
             <div key={i} className="p-4 glass rounded-2xl border border-white/5 hover:border-brand-gold/20 transition-colors">
               <item.icon className="w-5 h-5 text-brand-gold mb-3" />
               <h5 className="font-bold text-white text-xs mb-1">{item.title}</h5>
               <p className="text-[10px] text-slate-500 leading-snug">{item.desc}</p>
             </div>
           ))}
        </div>
      ),
      visual: (
        <div className="aspect-square glass-gold rounded-full flex flex-col items-center justify-center relative overflow-hidden border-2 border-dashed border-brand-gold/30">
           <div className="absolute inset-0 bg-brand-gold/10 animate-pulse" />
           <BrainCircuit className="w-24 h-24 text-brand-gold mb-4 relative z-10" />
           <div className="relative z-10 px-8 text-center">
              <p className="text-[10px] uppercase tracking-[0.3em] text-brand-gold font-black mb-2 animate-pulse">Groq Cloud Integration</p>
              <div className="h-1 w-32 bg-white/5 rounded-full overflow-hidden mx-auto">
                 <motion.div 
                   animate={{ x: [-128, 128] }} 
                   transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                   className="h-full w-1/2 bg-brand-gold shadow-[0_0_15px_rgba(197,160,89,0.8)]" />
              </div>
           </div>
        </div>
      )
    },
    {
      id: 5,
      section: "05. GESTIÓN DE INCIDENCIAS",
      title: <>Soporte Integral <br/> <span className="gold-gradient">& Chat Realtime</span></>,
      subtitle: "Resolviendo la brecha de comunicación entre el usuario y el equipo de soporte.",
      metrics: [
        { value: "FCM", label: "Push Notification" },
        { value: "Sync", label: "Live States" }
      ],
      content: (
        <div className="space-y-6">
          <p className="text-sm text-slate-400">
            Cada incidencia abre un canal de auditoría y chat directo. No es solo un ticket, es un historial de resolución colaborativo.
          </p>
          <div className="space-y-3">
             <div className="flex items-center gap-4 p-4 glass rounded-xl border-l-4 border-emerald-500">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                <div>
                   <p className="text-xs font-bold">Estado Dinámico</p>
                   <p className="text-[10px] text-slate-500">Transición auditada: Abierto &rarr; En Curso &rarr; Cerrado.</p>
                </div>
             </div>
             <div className="flex items-center gap-4 p-4 glass rounded-xl border-l-4 border-blue-500">
                <MessageSquare className="w-4 h-4 text-blue-400" />
                <div>
                   <p className="text-xs font-bold">Chat por Ticket</p>
                   <p className="text-[10px] text-slate-500">Canal de comunicación instantáneo por cada hilo de incidencia.</p>
                </div>
             </div>
          </div>
        </div>
      ),
      visual: (
        <div className="w-full flex justify-end">
           <div className="w-80 glass rounded-3xl p-6 relative shadow-2xl border-white/10">
              <div className="flex items-center justify-between mb-6 border-b border-white/5 pb-3">
                 <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">#INC-402</span>
                 <Tag color="purple">ALTA</Tag>
              </div>
              <div className="space-y-4 mb-4">
                 <div className="flex gap-2">
                    <div className="shrink-0 w-6 h-6 rounded-full bg-white/10" />
                    <div className="p-3 bg-white/5 rounded-2xl rounded-tl-none text-[9px] text-slate-300">Error 500 al persistir el IDE.</div>
                 </div>
                 <div className="flex gap-2 flex-row-reverse">
                    <div className="shrink-0 w-6 h-6 rounded-full bg-brand-gold" />
                    <div className="p-3 bg-brand-gold/10 rounded-2xl rounded-tr-none text-[9px] text-brand-gold border border-brand-gold/30">Límite PgBouncer alcanzado, reinícialo.</div>
                 </div>
              </div>
              <div className="p-3 glass rounded-full flex justify-between items-center bg-white/[0.02]">
                 <span className="text-[8px] text-slate-600 px-2 italic">Escribe un mensaje...</span>
                 <Zap className="w-3 h-3 text-brand-gold" />
              </div>
           </div>
        </div>
      )
    },
    {
      id: 6,
      section: "06. ADMINISTRACIÓN & AUDITORÍA",
      title: <>El Control <br/> <span className="gold-gradient">del Administrador</span></>,
      subtitle: "Supervisión total de roles, usuarios y trazabilidad de acciones mediante Spring AOP.",
      metrics: [
        { value: "RBAC", label: "Security Level" },
        { value: "360º", label: "Auditoría Log" }
      ],
      content: (
        <div className="space-y-6">
          <p className="text-sm text-slate-400">
            Un panel diseñado para el Staff y Administradores, permitiendo el control sobre el flujo de trabajo y la seguridad de la información.
          </p>
          <div className="grid grid-cols-2 gap-4">
             <div className="p-4 glass rounded-2xl">
                <Users className="w-6 h-6 text-brand-gold mb-3" />
                <h5 className="text-xs font-bold">Usuarios & Roles</h5>
                <p className="text-[10px] text-slate-600">Gestión de departamentos técnicos y niveles de acceso.</p>
             </div>
             <div className="p-4 glass rounded-2xl">
                <ShieldCheck className="w-6 h-6 text-brand-gold mb-3" />
                <h5 className="text-xs font-bold">Logs de Sistema</h5>
                <p className="text-[10px] text-slate-600">Registro histórico de cada mutación de datos en la plataforma.</p>
             </div>
          </div>
        </div>
      ),
      visual: (
        <div className="glass rounded-3xl p-8 border-white/10 shadow-2xl overflow-hidden relative">
           <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
              <ShieldCheck className="w-32 h-32 text-brand-gold" />
           </div>
           <div className="space-y-4">
              <div className="flex items-center justify-between text-[10px] uppercase font-bold text-slate-500 border-b border-white/5 pb-2">
                 <span>Acción Global</span>
                 <span>Estado</span>
              </div>
              {[
                { a: "USER_LOGIN_GRANT", s: "Success", c: "emerald" },
                { a: "DATABASE_MIGRATE_V4", s: "Complete", c: "blue" },
                { a: "DIARY_VISIBILITY_CHG", s: "Audited", c: "amber" },
                { a: "FCM_PUSH_DISPATCH", s: "Sent", c: "emerald" },
              ].map((log, i) => (
                <div key={i} className="flex items-center justify-between">
                   <span className="text-[9px] font-mono text-slate-400">{log.a}</span>
                   <span className={`text-[8px] px-2 py-0.5 rounded-full bg-${log.c}-500/10 text-${log.c}-400 border border-${log.c}-500/20`}>{log.s}</span>
                </div>
              ))}
           </div>
        </div>
      )
    },
    {
      id: 7,
      section: "07. INFRAESTRUCTURA & SEGURIDAD",
      title: <>Servidor VPS <br/> <span className="gold-gradient">Propio & Robusto</span></>,
      subtitle: "Un despliegue profesional con balanceo, backups y seguridad perimetral.",
      metrics: [
        { value: "Bakup", label: "Automatizados" },
        { value: "SSL", label: "Auto-Renewal" }
      ],
      content: (
        <div className="grid grid-cols-2 gap-6 pt-4">
           <div className="space-y-4">
              <div className="p-4 glass rounded-2xl border-l-2 border-brand-gold">
                 <h5 className="text-white text-xs font-bold mb-1">Capa de Persistencia</h5>
                 <p className="text-[10px] text-slate-500">PostgreSQL 17 gestionado con <strong>PgBouncer</strong> para un pool de hilos optimizado y eficiente bajo carga.</p>
              </div>
              <div className="p-4 glass rounded-2xl border-l-2 border-brand-gold">
                 <h5 className="text-white text-xs font-bold mb-1">Seguridad Firebase</h5>
                 <p className="text-[10px] text-slate-500">Arquitectura "Zero-Trust" con reglas de seguridad granulares que protegen los datos en tiempo real.</p>
              </div>
           </div>
           <div className="space-y-4">
              <div className="p-4 glass rounded-2xl border-l-2 border-brand-gold">
                 <h5 className="text-white text-xs font-bold mb-1">Bots de Mantenimiento</h5>
                 <p className="text-[10px] text-slate-500">Scripts automáticos para monitorización de salud del sistema, backups diarios y logs de auditoría.</p>
              </div>
              <div className="p-4 glass rounded-2xl border-l-2 border-brand-gold">
                 <h5 className="text-white text-xs font-bold mb-1">PWA Ready</h5>
                 <p className="text-[10px] text-slate-500">Ya disponible en móvil mediante Service Workers, ofreciendo una experiencia nativa sin fricciones.</p>
              </div>
           </div>
        </div>
      ),
      visual: (
        <div className="relative p-10 glass rounded-3xl border-white/5 bg-slate-900/50">
           <div className="flex flex-col gap-6">
              <div className="flex items-center gap-4">
                 <div className="w-4 h-4 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_15px_rgba(16,185,129,0.5)]" />
                 <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest">vps-production-node-01: active</span>
              </div>
              <div className="space-y-3 font-mono text-[9px] text-slate-400">
                 <p className="opacity-60 text-brand-gold">{" >> "} loading security_v2.rules...</p>
                 <p className="opacity-80">{" >> "} pgbouncer_pool_limit: 10000_connections</p>
                 <p className="opacity-80">{" >> "} nightly_backup_status: verified_ok</p>
                 <p className="opacity-80 text-blue-400">{" >> "} firebase_auth_handshake: encrypted</p>
              </div>
              <div className="pt-4 border-t border-white/5">
                 <div className="flex justify-between">
                    <Database className="w-8 h-8 text-brand-gold opacity-50" />
                    <ShieldCheck className="w-8 h-8 text-emerald-500 opacity-50" />
                    <Cpu className="w-8 h-8 text-blue-500 opacity-50" />
                 </div>
              </div>
           </div>
        </div>
      )
    },
    {
      id: 8,
      section: "08. COLABORACIÓN & STAFF",
      title: <>Ecosistema <br/> <span className="gold-gradient">Social Técnico</span></>,
      subtitle: "Invitaciones a proyectos, feedback de tutores y visualización en vivo.",
      metrics: [
        { value: "Live", label: "Play Mode" },
        { value: "Feedback", label: "Staff-Student" }
      ],
      content: (
        <div className="space-y-6">
          <p className="text-sm text-slate-400">
            DevNexus no es una herramienta aislada. Permite heredar valor de la comunidad técnica mediante:
          </p>
          <div className="grid grid-cols-2 gap-4">
             <div className="p-4 glass rounded-2xl hover:bg-brand-gold/5 transition-colors border border-white/5">
                <Users className="w-6 h-6 text-brand-gold mb-3" />
                <h5 className="text-xs font-bold text-white uppercase tracking-widest">Invitación</h5>
                <p className="text-[10px] text-slate-500">Añade colaboradores a tus diarios o proyectos con roles específicos.</p>
             </div>
             <div className="p-4 glass rounded-2xl hover:bg-brand-gold/5 transition-colors border border-white/5">
                <MessageSquare className="w-6 h-6 text-brand-gold mb-3" />
                <h5 className="text-xs font-bold text-white uppercase tracking-widest">F. Tutor</h5>
                <p className="text-[10px] text-slate-500">Sistema de revisión donde el staff puede dejar correcciones directas.</p>
             </div>
          </div>
          <div className="p-4 glass rounded-2xl bg-white/[0.02] flex items-center gap-4">
             <Zap className="w-5 h-5 text-brand-gold" />
             <p className="text-[11px] font-bold uppercase tracking-widest text-brand-gold">Botón "PLAY": Renderizado inmediato de prototipos compartidos.</p>
          </div>
        </div>
      ),
      visual: (
        <div className="aspect-square flex items-center justify-center relative">
           <div className="absolute inset-0 bg-brand-gold/5 blur-[100px] rounded-full" />
           <div className="relative group cursor-pointer">
              <div className="absolute inset-0 bg-brand-gold/20 rounded-full blur-[40px] group-hover:blur-[60px] transition-all" />
              <div className="relative w-32 h-32 glass rounded-full border-2 border-brand-gold flex items-center justify-center shadow-[0_0_50px_rgba(197,160,89,0.4)] group-hover:scale-105 transition-transform">
                 <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[20px] border-l-brand-gold border-b-[10px] border-b-transparent ml-2" />
              </div>
              <p className="absolute -bottom-10 left-1/2 -translate-x-1/2 text-[9px] uppercase tracking-[0.4em] font-black text-brand-gold whitespace-nowrap opacity-60">Visualizar Proyecto</p>
           </div>
        </div>
      )
    },
    {
      id: 9,
      section: "09. ROADMAP",
      title: <>Futuras <br/> <span className="gold-gradient">Líneas</span></>,
      subtitle: "Evolución planificada hacia un entorno de ingeniería automatizado.",
      metrics: [
        { value: "Git", label: "Sync Ready" },
        { value: "AI", label: "Auto-Doc" }
      ],
      content: (
        <div className="space-y-4">
          {[
            { t: "Integración Git Directa", d: "Sincronización con commits de GitHub." },
            { t: "Marketplace de Snippets", d: "Repositorio comunitario de código verificado." },
            { t: "Mobile Native (Capacitor)", d: "Empaquetado para Play Store / App Store." },
          ].map((f, i) => (
            <div key={i} className="flex gap-4 p-3 glass rounded-xl border-l-2 border-brand-gold/50">
              <ArrowRight className="w-4 h-4 text-brand-gold shrink-0 mt-1" />
              <div>
                <h5 className="text-xs font-bold text-white">{f.t}</h5>
                <p className="text-[10px] text-slate-500">{f.d}</p>
              </div>
            </div>
          ))}
        </div>
      ),
      visual: (
        <div className="relative h-64 flex items-center justify-center">
           <div className="absolute inset-0 bg-brand-gold/5 blur-[60px] rounded-full" />
           <div className="flex gap-4 items-end h-full py-8">
              <div className="w-12 bg-white/5 h-1/4 rounded-t-lg border-t-2 border-white/10" />
              <div className="w-12 bg-white/10 h-2/4 rounded-t-lg border-t-2 border-white/20" />
              <div className="w-12 bg-brand-gold/20 h-3/4 rounded-t-lg border-t-2 border-brand-gold/50" />
              <div className="w-12 bg-brand-gold/40 h-full rounded-t-lg border-t-2 border-brand-gold shadow-[0_0_20px_rgba(197,160,89,0.3)] animat-pulse" />
           </div>
        </div>
      )
    },
    {
      id: 9,
      section: "09. VIABILIDAD & CONCLUSIONES",
      title: <>Resultados <br/> <span className="gold-gradient">del TFG</span></>,
      subtitle: "Un proyecto que resuelve problemas reales sin costes de infraestructura.",
      metrics: [
        { value: "100%", label: "RF Cumplidos" },
        { value: "0€", label: "Inversión Cloud" }
      ],
      content: (
        <div className="space-y-8 pt-4">
          <p className="text-sm text-slate-400 leading-relaxed font-light">
            DevNexus demuestra que es posible construir herramientas de gestión técnica de alta fidelidad utilizando tecnologías Open Source y arquitecturas escalables modernas.
          </p>
          <div className="grid grid-cols-3 gap-4">
             <div className="text-center">
                <p className="text-2xl font-serif text-white">20+</p>
                <p className="text-[9px] text-slate-500 uppercase tracking-widest mt-1">Interfaces</p>
             </div>
             <div className="text-center">
                <p className="text-2xl font-serif text-white">100%</p>
                <p className="text-[9px] text-slate-500 uppercase tracking-widest mt-1">Web/Mobile</p>
             </div>
             <div className="text-center">
                <p className="text-2xl font-serif text-white">v4</p>
                <p className="text-[9px] text-slate-500 uppercase tracking-widest mt-1">DB Migrates</p>
             </div>
          </div>
          <div className="p-5 glass border-brand-gold/30 rounded-2xl flex items-center gap-4 bg-brand-gold/5">
            <Zap className="w-6 h-6 text-brand-gold" />
            <p className="text-[11px] font-bold text-brand-gold/80 uppercase tracking-[0.2em]">Listo para el despliegue comercial</p>
          </div>
        </div>
      ),
      visual: (
        <div className="flex flex-col items-center justify-center space-y-6">
           <div className="relative">
              <div className="absolute inset-0 bg-brand-gold/20 blur-[80px] rounded-full animate-pulse" />
              <div className="relative p-10 glass rounded-full border-2 border-brand-gold bg-brand-gold/10">
                 <ShieldCheck className="w-20 h-20 text-brand-gold" />
              </div>
           </div>
           <div className="flex gap-3">
              <Tag color="purple">Backend Ready</Tag>
              <Tag color="blue">PWA Success</Tag>
           </div>
        </div>
      )
    },
    {
      id: 10,
      section: "DESPEDIDA",
      title: <>Muchas <br/> <span className="gold-gradient">Gracias</span></>,
      subtitle: "Quedo a su disposición para cualquier pregunta técnica o funcional.",
      content: (
        <div className="flex flex-col justify-end h-full">
          <div className="pt-12 border-t border-white/5 space-y-6">
             <div className="grid grid-cols-2 gap-8">
                <div>
                   <p className="text-[10px] uppercase tracking-[0.3em] text-slate-600 mb-1 font-black">Centro Educativo</p>
                   <p className="text-sm font-serif italic text-slate-300">IES Rafael Alberti, Cádiz</p>
                </div>
                <div>
                   <p className="text-[10px] uppercase tracking-[0.3em] text-slate-600 mb-1 font-black">Grado Superior</p>
                   <p className="text-sm font-serif italic text-slate-300">Desarrollo Multiplataforma</p>
                </div>
             </div>
             <div className="flex items-center gap-4 pt-4">
                <div className="w-12 h-0.5 bg-brand-gold opacity-50" />
                <p className="text-[11px] uppercase tracking-[0.4em] text-brand-gold font-black">DevNexus • 2026</p>
             </div>
          </div>
        </div>
      ),
      visual: (
        <div 
          className="group relative cursor-pointer" 
          onClick={() => {
            setDirection(-1);
            setCurrentSlide(0);
          }}
        >
          <div className="absolute inset-0 bg-brand-gold/20 blur-[100px] group-hover:bg-brand-gold/40 transition-all rounded-full" />
          <div className="relative p-20 glass rounded-full border border-brand-gold/30 hover:border-brand-gold transition-colors flex flex-col items-center">
             <Code2 className="w-24 h-24 text-white mb-4 animate-float" />
             <span className="text-[10px] text-brand-gold uppercase tracking-[0.5em] font-black group-hover:scale-110 transition-transform">Volver al Inicio</span>
          </div>
        </div>
      )
    }
  ];

  const nextSlide = useCallback(() => {
    if (currentSlide < slides.length - 1) {
      setDirection(1);
      setCurrentSlide(s => s + 1);
    }
  }, [currentSlide, slides.length]);

  const prevSlide = useCallback(() => {
    if (currentSlide > 0) {
      setDirection(-1);
      setCurrentSlide(s => s - 1);
    }
  }, [currentSlide]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') nextSlide();
      if (e.key === 'ArrowLeft') prevSlide();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [nextSlide, prevSlide]);

  return (
    <div className="relative h-screen w-screen bg-[#0A0A0A] text-slate-100 overflow-hidden font-sans">
      {/* Background Decor */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 right-0 w-[50%] h-[50%] bg-brand-gold/5 blur-[150px] transform translate-x-1/4 -translate-y-1/4 rounded-full" />
        <div className="absolute bottom-0 left-0 w-[40%] h-[40%] bg-white/5 blur-[120px] transform -translate-x-1/4 translate-y-1/4 rounded-full" />
      </div>

      {/* Floating Global Progress & Nav (Minimal) */}
      <div className="absolute top-6 right-12 z-[60] flex items-center gap-6">
          {currentSlide > 0 && (
            <div className="flex items-center gap-3 px-3 py-1.5 glass rounded-full border-white/5">
               <span className="text-[10px] font-serif italic text-white/40">0{currentSlide + 1}</span>
               <div className="w-8 h-[1px] bg-white/10" />
               <span className="text-[9px] uppercase tracking-widest text-brand-gold font-bold">DevNexus</span>
            </div>
          )}
      </div>

      {/* Side Navigation Dots */}
      <div className="absolute left-8 top-1/2 -translate-y-1/2 z-[60] hidden md:flex flex-col gap-3">
        {slides.map((s, i) => (
          <button
            key={i}
            onClick={() => {
              setDirection(i > currentSlide ? 1 : -1);
              setCurrentSlide(i);
            }}
            className={`w-1.5 h-1.5 rounded-full transition-all duration-300 cursor-pointer ${
              currentSlide === i ? 'h-6 bg-brand-gold' : 'bg-white/10 hover:bg-white/30'
            }`}
            aria-label={`Ir a slide ${i + 1}`}
          />
        ))}
      </div>

      {/* Main Slide Content */}
      <main className="relative h-full w-full">
        <AnimatePresence mode="wait" custom={direction}>
          <Slide key={currentSlide} slide={slides[currentSlide]} direction={direction} currentSlide={currentSlide} />
        </AnimatePresence>
      </main>

      {/* Navigation Floating Buttons */}
      <div className="absolute bottom-8 right-12 z-[60] flex gap-3">
          <button 
            onClick={prevSlide} 
            disabled={currentSlide === 0} 
            className={`w-10 h-10 glass rounded-full flex items-center justify-center hover:bg-white/10 transition-all ${currentSlide === 0 ? 'opacity-0' : 'opacity-100'} cursor-pointer border-white/10 shadow-xl`}
          >
            <ChevronLeft className="w-5 h-5 text-slate-400" />
          </button>
          <button 
            onClick={nextSlide} 
            disabled={currentSlide === slides.length - 1} 
            className="w-10 h-10 glass rounded-full flex items-center justify-center hover:bg-white/10 transition-all cursor-pointer border-white/10 shadow-xl"
          >
            <ChevronRight className="w-5 h-5 text-slate-400" />
          </button>
      </div>
    </div>
  );
}
